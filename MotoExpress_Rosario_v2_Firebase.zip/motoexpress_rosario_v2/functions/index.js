const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onDocumentCreated}=require('firebase-functions/v2/firestore');
const {initializeApp}=require('firebase-admin/app');
const {getFirestore,FieldValue}=require('firebase-admin/firestore');
initializeApp(); const db=getFirestore(); const REGION='us-central1';
const services=['Comida','Compras y mandados','Paquetes','Documentos','Farmacia (artículos permitidos)','Otro'];
const requireUser=req=>{if(!req.auth)throw new HttpsError('unauthenticated','Inicia sesión');return req.auth.uid};
const isAdmin=req=>req.auth?.token?.admin===true;
const str=(v,max=180)=>typeof v==='string'?v.trim().slice(0,max):'';
const price=km=>km<=2?1.5:km<=5?2.5:4;
exports.createOrder=onCall({region:REGION,enforceAppCheck:false},async req=>{
 const uid=requireUser(req),d=req.data||{},km=Number(d.km);
 if(!services.includes(d.service)||!str(d.pickup,240)||!str(d.dropoff,240)||!Number.isFinite(km)||km<0.1||km>10||!['Efectivo','Pago móvil','Transferencia'].includes(d.payment))throw new HttpsError('invalid-argument','Revisa los datos del pedido');
 const doc=await db.collection('orders').add({customerId:uid,driverId:null,service:d.service,pickup:str(d.pickup,240),dropoff:str(d.dropoff,240),notes:str(d.notes,240),km,price:price(km),payment:d.payment,status:'pending',createdAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp()});
 return {id:doc.id};
});
exports.setAvailability=onCall({region:REGION},async req=>{
 const uid=requireUser(req),online=req.data?.online;
 if(typeof online!=='boolean')throw new HttpsError('invalid-argument','Disponibilidad inválida');
 const ref=db.collection('drivers').doc(uid);
 await db.runTransaction(async tx=>{const snap=await tx.get(ref);if(!snap.exists||snap.data().approved!==true)throw new HttpsError('permission-denied','Motorizado no aprobado');tx.update(ref,{online,updatedAt:FieldValue.serverTimestamp()})});
 return {online};
});
exports.advanceOrder=onCall({region:REGION},async req=>{
 const uid=requireUser(req),id=str(req.data?.id,120),next=str(req.data?.status,30);
 if(!id||!['picked_up','on_way','delivered'].includes(next))throw new HttpsError('invalid-argument','Estado inválido');
 const ref=db.collection('orders').doc(id);
 await db.runTransaction(async tx=>{const snap=await tx.get(ref);if(!snap.exists)throw new HttpsError('not-found','Pedido no encontrado');const o=snap.data();if(o.driverId!==uid)throw new HttpsError('permission-denied','Pedido no asignado a ti');const allowed={assigned:'picked_up',picked_up:'on_way',on_way:'delivered'};if(allowed[o.status]!==next)throw new HttpsError('failed-precondition','Transición no permitida');tx.update(ref,{status:next,updatedAt:FieldValue.serverTimestamp()});if(next==='delivered')tx.update(db.collection('drivers').doc(uid),{busy:false,updatedAt:FieldValue.serverTimestamp()})});return {ok:true};
});
exports.adminAction=onCall({region:REGION},async req=>{
 requireUser(req);if(!isAdmin(req))throw new HttpsError('permission-denied','Solo administración');
 const action=req.data?.action,uid=str(req.data?.uid,128),id=str(req.data?.id,128);
 if(action==='approveDriver'&&uid){await db.collection('drivers').doc(uid).set({approved:true,online:false,busy:false,updatedAt:FieldValue.serverTimestamp()},{merge:true});return {ok:true}}
 if(action==='disableDriver'&&uid){await db.collection('drivers').doc(uid).set({approved:false,online:false,updatedAt:FieldValue.serverTimestamp()},{merge:true});return {ok:true}}
 if(action==='cancelOrder'&&id){const ref=db.collection('orders').doc(id);await db.runTransaction(async tx=>{const snap=await tx.get(ref);if(!snap.exists)throw new HttpsError('not-found','Pedido no encontrado');const o=snap.data();if(['delivered','cancelled'].includes(o.status))throw new HttpsError('failed-precondition','Pedido cerrado');tx.update(ref,{status:'cancelled',updatedAt:FieldValue.serverTimestamp()});if(o.driverId)tx.update(db.collection('drivers').doc(o.driverId),{busy:false,updatedAt:FieldValue.serverTimestamp()})});return {ok:true}}
 throw new HttpsError('invalid-argument','Acción inválida');
});
// Assign once per new order. A scheduled retry worker is needed for orders without online drivers.
exports.autoAssign=onDocumentCreated({document:'orders/{id}',region:REGION},async event=>{
 const ref=event.data?.ref;if(!ref)return;
 const candidates=await db.collection('drivers').where('approved','==',true).where('online','==',true).limit(40).get();
 for(const d of candidates.docs){
  const assigned=await db.runTransaction(async tx=>{
   const [order,driver]=await Promise.all([tx.get(ref),tx.get(d.ref)]);
   if(!order.exists||order.data().status!=='pending'||!driver.exists||!driver.data().approved||!driver.data().online||driver.data().busy)return false;
   tx.update(d.ref,{busy:true,lastAssignedAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp()});
   tx.update(ref,{driverId:d.id,status:'assigned',updatedAt:FieldValue.serverTimestamp()});return true;
  });if(assigned)return;
 }
});
exports.applyDriver=onCall({region:REGION},async req=>{
 const uid=requireUser(req),name=str(req.data?.name,90),phone=str(req.data?.phone,30),plate=str(req.data?.plate,30);
 if(!name||!phone||!plate)throw new HttpsError('invalid-argument','Completa nombre, teléfono y placa');
 const ref=db.collection('drivers').doc(uid),snap=await ref.get();
 if(snap.exists)throw new HttpsError('already-exists','Solicitud registrada');
 await ref.set({name,phone,plate,approved:false,online:false,busy:false,createdAt:FieldValue.serverTimestamp()});return {ok:true};
});
exports.assignPending=onCall({region:REGION},async req=>{
 const uid=requireUser(req);const d=await db.collection('drivers').doc(uid).get();
 if(!d.exists||!d.data().approved||!d.data().online||d.data().busy)throw new HttpsError('failed-precondition','No disponible');
 const orders=await db.collection('orders').where('status','==','pending').limit(15).get();
 for(const o of orders.docs){const assigned=await db.runTransaction(async tx=>{
  const [os,ds]=await Promise.all([tx.get(o.ref),tx.get(d.ref)]);
  if(!os.exists||os.data().status!=='pending'||!ds.exists||!ds.data().approved||!ds.data().online||ds.data().busy)return false;
  tx.update(d.ref,{busy:true,updatedAt:FieldValue.serverTimestamp()});tx.update(o.ref,{driverId:uid,status:'assigned',updatedAt:FieldValue.serverTimestamp()});return true;
 });if(assigned)return {assigned:true,id:o.id};}return {assigned:false};
});
