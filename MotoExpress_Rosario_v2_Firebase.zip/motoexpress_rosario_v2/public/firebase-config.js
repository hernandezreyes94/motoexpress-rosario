// Sustituye estos valores por los de Firebase Console > Configuración del proyecto > Tus aplicaciones.
export const firebaseConfig = {
 apiKey: 'REEMPLAZAR', authDomain: 'REEMPLAZAR', projectId: 'REEMPLAZAR',
 appId: 'REEMPLAZAR'
};
